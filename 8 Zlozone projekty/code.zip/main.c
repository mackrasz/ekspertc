#include <stdio.h>
#include "libmath.h"

int main()
{
    printf("%d", sub(add(1, 2), 1));

    return 0;
}